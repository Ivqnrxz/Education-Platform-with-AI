
from transformers import pipeline

# Initialize the AI model (using a pre-trained model like GPT-2 or GPT-3)
qa_model = pipeline('question-answering')

def get_ai_response(question):
    context = '''
    AI is a broad field of computer science that involves creating machines capable of performing tasks that typically require human intelligence. Examples include speech recognition, decision-making, and language translation.
    '''
    
    answer = qa_model({'question': question, 'context': context})
    return answer['answer']

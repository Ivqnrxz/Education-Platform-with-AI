
from flask import render_template, request
from app import app
from app.models import get_ai_response

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    question = request.form['question']
    answer = get_ai_response(question)
    return render_template('index.html', question=question, answer=answer)
